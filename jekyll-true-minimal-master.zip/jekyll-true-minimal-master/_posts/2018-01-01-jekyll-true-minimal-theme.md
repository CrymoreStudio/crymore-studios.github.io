---
layout: post
title:  "Jekyll true minimal theme"
date:   2018-01-01 23:22:40 +0300
---

True minimal theme is extremely lightweight and ascetic jekyll theme.

This theme has only one css file, which is used for source code highlighting. 


# Heading 1
## Heading 2
### Heading 3

List of entries:

- item 1
- item 2
- item 3
- item 4

Source code are highlighted:

```perl
#!/usr/bin/perl

sub print_hello {
    print "Hello, Jekyll!\n";
}

print_hello;
```
    